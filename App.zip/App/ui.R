ui <- dashboardPagePlus(title = "Story Telling - Time Americans Spend Sleeping",
                        useShinyalert(),
                        
                        
                        enable_preloader = T, loading_duration = 3,
                        header = dashboardHeaderPlus(title = "Dashboard"),
                        sidebar = dashboardSidebar(
                          sidebarMenu(
                            menuItem("Data Overview", tabName = "Overview", icon = icon("dashboard")),
                            menuItem("Sleep Analysis", tabName = "Analysis", icon = icon("chart-bar"))
                          )    
                        ),
                        body = dashboardBody(
                          fluidRow(
                            tabItems(
                            # First tab content
                            tabItem(tabName = "Overview",
                            column(7,
                                   boxPlus(title = "Data Overview",solidHeader = T,status = "primary",closable = F,width = 12,
                                           withSpinner(DT::dataTableOutput("data_table"),type = 8)
                                           
                                           
                                           )
                                   
                                   ),
                            column(5,
                                   panel(align = 'center',status = "primary",style="height: 420px;",
                                         plotlyOutput("donut_plot")
                                         
                                   )

                            ),
                            column(7,
                                   boxPlus(align = 'center',status = "primary",solidHeader = T,width = 12,height = "400px",
                                           br(),
                                          plotlyOutput("subplot"))
                            ),
                            column(5,
                                   boxPlus(align = 'center',status = "primary",solidHeader = T,width = 12,height = "400px",
                                  
                                   plotlyOutput("both_hist")
                                    
                                   )   
                                  
                                   )
                            
                            ), # end first tab
                            
                            # Second tab content
                            tabItem(tabName = "Analysis",
                            fluidRow(
                            
                            column(12,
                                   boxPlus(title = "Sleep Analysis",solidHeader = T,status = "success",
                                           closable = F,width = 12,
                                           
                                           column(5,
                                                  pickerInput(inputId = "day_Select",label = "Select Day Type",choices = unique(actual_data$Day_Type),selected = unique(actual_data$Day_Type)[1], multiple = F,
                                                    options = list(`actions-box` = TRUE)
                                                  )
                                                  
                                                  ),
                                           column(2, style = "height: 20px;", ""),
                                           column(5,
                                                  pickerInput(inputId = "age_select",label = "Select Age Group",choices = unique(actual_data$Age_Group),selected = unique(actual_data$Age_Group)[1],multiple = F,
                                                              options = list(`actions-box` = TRUE)
                                                  )
                                           ),
                                                  br(),
                                                  column(8,
                                                         plotlyOutput("animation") 
                                                         ),
                                                  column(4,
                                                         plotlyOutput("hist1")
                                                         )
                                                  
                                                  
                                           ) # end Boxplus

                                   
                            ),# end column 10
                            column(2, style = "height: 20px;", ""),
                            br(),
                            column(12,
                                   boxPlus(title = "Error Analysis",solidHeader = T,status = "warning",
                                           closable = F,width = 12,
                                           
                                           column(4,
                                                  pickerInput(inputId = "gender",label = "Select Gender",choices = unique(Time_Americans_Spend_Sleeping$Sex),selected = unique(Time_Americans_Spend_Sleeping$Sex)[1], multiple = F,
                                                              options = list(`actions-box` = TRUE)
                                                  )
                                                  
                                           ),
                                           
                                           column(4,
                                                  pickerInput(inputId = "day_Select1",label = "Select Day Type",choices = unique(Time_Americans_Spend_Sleeping$Day_Type),selected = unique(Time_Americans_Spend_Sleeping$Day_Type)[1], multiple = F,
                                                              options = list(`actions-box` = TRUE)
                                                  )
                                                  
                                           ),

                                           column(4,
                                                  pickerInput(inputId = "age_select1",label = "Select Age Group",choices = unique(Time_Americans_Spend_Sleeping$Age_Group),selected = unique(Time_Americans_Spend_Sleeping$Age_Group)[1],multiple = F,
                                                              options = list(`actions-box` = TRUE)
                                                  )
                                           ),
                                           br(),
                                           column(12,
                                                  plotlyOutput("error_analysis") 
                                           )
                                           
                                           
                                   ) # end Boxplus       
                                   
                                   ),
                            column(2, style = "height: 20px;", ""),
                            br(),
                            column(12,
                                   boxPlus(title = "Boxplot Distribution",solidHeader = T,status = "info",
                                           closable = F,width = 12,
                                           
                                           column(4,
                                                  pickerInput(inputId = "gender2",label = "Select Gender",choices = unique(Time_Americans_Spend_Sleeping$Sex),selected = unique(Time_Americans_Spend_Sleeping$Sex)[1], multiple = F,
                                                              options = list(`actions-box` = TRUE)
                                                  )
                                                  
                                           ),
                                           
                                           column(4,
                                                  pickerInput(inputId = "day_Select2",label = "Select Day Type",choices = unique(Time_Americans_Spend_Sleeping$Day_Type),selected = unique(Time_Americans_Spend_Sleeping$Day_Type)[1], multiple = F,
                                                              options = list(`actions-box` = TRUE)
                                                  )
                                                  
                                           ),
                                           
                                           br(),
                                           column(12,
                                                  plotlyOutput("boxplot_analysis") 
                                           )
                                           
                                           
                                   ) # end Boxplus       
                                   
                            )
                            
                            
                              
                              
                              
                            )# end fluidRow        
                            ) # end second tab
                            
                            
                            
                          ) # end tab Items
                          
                          )  # end fluidRow  
                          
                        ) # end dashboardbody

  
  
  ) # end Ui



# shinyApp(ui,server)