
server = function(input, output, session) {
  
  
  # Show Data 
  
  output$data_table <-  DT::renderDataTable({
      
    
    DT::datatable(Time_Americans_Spend_Sleeping,filter = 'top',caption = "Table showing data", options = list(dom='tip',paging=T,pagelength=10,columnDefs = list(list(className = 'dt-center', targets = 0:5))),class = 'cell-border stripe nowrap',rownames = FALSE)
      
      
    })
  
  
  
  
  # Donut Chart explaining Male Female Ratio

  output$donut_plot <- renderPlotly({
    
    
  p <- actual_data %>%
    group_by(Sex) %>%
    summarize(count = n()) %>%
    plot_ly(labels = ~Sex, values = ~count) %>%
    add_pie(hole = 0.6) %>%
    layout(title = "Male ~ Female Proportion",  showlegend = F,
           xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
           yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  

  
  
})

  
  
  # Sub Plot expaining data distribution Age ~ Genders
  output$subplot <- renderPlotly({
    
    # SubPlots :  Male - Female 
    p1 <- plot_ly() %>%
      add_pie(data = count(subset(Time_Americans_Spend_Sleeping,Sex=="Men"), Age_Group), labels = ~Age_Group, values = ~n,
              name = "Men", domain = list(x = c(0, 0.4), y = c(0.4, 1))) %>%
      add_pie(data = count(subset(Time_Americans_Spend_Sleeping,Sex=="Women"), Age_Group), labels = ~Age_Group, values = ~n,
              name = "Women", domain = list(x = c(0.6, 1), y = c(0.4, 1))) %>%
      layout(title = "Data Distribution : Genders ~ Age Group", showlegend = F, width = 700, height = 370,
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    
    
    
    
  })
  
  
  # show overall histogram
  
  
  output$both_hist <- renderPlotly({
    
    # Change line color and fill color
   p2 <-  ggplot(both_data, aes(x=Avg_Sleeping_hours)) +
      geom_histogram(color="darkblue", fill="lightblue") + 
      ggtitle("How many hours do American's sleep")
   
   ggplotly(p2)
   
   
   
    
    
  })
  
  
  # ----------------------- Cumulative Lines Animation  ----------------------- #
  observe({
    input$day_Select
    input$age_select
    

    if(is.null(input$day_Select) | is.null(input$age_select))
    {
      
      shinyalert(title = "Warning",text = "Input fields cannot be blank...",type = "error",closeOnEsc = T,closeOnClickOutside = T,showConfirmButton = F,timer = 1200)
      
      
      
    }else{  
    Day_Type1  <<- input$day_Select
    Age_Group1  <<- input$age_select
    
    actual_data1 <<- subset(actual_data,((Day_Type %in% Day_Type1) & (Age_Group %in% Age_Group1)))  
    
    
    d <<- actual_data1 %>%
      accumulate_by(~Year)
    
    
    output$animation <- renderPlotly({
      
    p3 <- d %>%
      plot_ly(
        x = ~Year, 
        y = ~Avg_Sleeping_hours,
        split = ~Sex,
        frame = ~frame, 
        type = 'scatter',
        mode = 'lines', 
        line = list(simplyfy = F)
      ) %>% 
      layout(
        xaxis = list(
          title = "Date",
          zeroline = F
        ),
        yaxis = list(
          title = "Avg_Sleeping_hours",
          zeroline = F
        )
      ) %>% 
      animation_opts(
        frame = 100, 
        transition = 0, 
        redraw = FALSE
      ) %>%
      animation_slider(
        hide = T
      ) %>%
      animation_button(
        x = 1, xanchor = "right", y = 0, yanchor = "bottom"
      )
    
    

    
    })
    
    
    output$hist1 <- renderPlotly({
      
      f <- list(
        family = "Courier New, monospace",
        size = 18,
        color = "#7f7f7f"
      )
      
      x <- list(
        title = "Average Sleeping Hours",
        titlefont = f
      )
      y <- list(
        title = "Count",
        titlefont = f
      )
      p6 <- plot_ly(alpha = 0.5) %>%
        add_histogram(data = actual_data1,x = ~actual_data1$Avg_Sleeping_hours[actual_data1$Sex=="Men"],name='Men') %>%
        add_histogram(data = actual_data1,x = ~actual_data1$Avg_Sleeping_hours[actual_data1$Sex=="Women"],name='Women') %>%
        layout(barmode = "overlay",xaxis = x, yaxis = y)
    
      
    })
    
    

    
    }
      
  })
  
  
  
  # ----------------------- Error Analysis ----------------------- #
  observe({
    input$day_Select1
    input$age_select1
    input$gender
    
    if(is.null(input$day_Select) | is.null(input$age_select) | is.null(input$gender))
    {
      
      shinyalert(title = "Warning",text = "Input fields cannot be blank...",type = "error",closeOnEsc = T,closeOnClickOutside = T,showConfirmButton = F,timer = 1200)
      
      
      
    }else{ 
    
      Day_Type1  <<- input$day_Select1
      Age_Group1  <<- input$age_select1
      gender      <<- input$gender
      
      temp_data1 <- subset(Time_Americans_Spend_Sleeping,Day_Type %in% Day_Type1  & Age_Group %in% input$age_select1 & Sex %in% gender)
      
      output$error_analysis <- renderPlotly({
      p1 <- plot_ly(temp_data1, x = ~Year, y = ~Avg_Sleeping_hours) %>%
        add_lines(name = ~"Avg_Sleeping_hours")
      
      p2 <- plot_ly(temp_data1, x = ~Year, y = ~Standard_Error) %>%
        add_lines(name = ~"Standard_Error")
      
      
      p4 <- subplot(p1, p2)
      })
    
      } # end else
    
  })
  
  
  
  # ----------------------- Several Boxplots ----------------------- #
  observe({
    
    input$day_Select2
    input$gender2
    
    print("Observe Hit")
    
    
    if(is.null(input$day_Select2) | is.null(input$gender2) )
    {
      
      shinyalert(title = "Warning",text = "Input fields cannot be blank...",type = "error",closeOnEsc = T,closeOnClickOutside = T,showConfirmButton = F,timer = 1200)
      
      
      
    }else{
      
      Day_Type2  <<- input$day_Select2
      gender2      <<- input$gender2
      
      temp_data2 <<- subset(Time_Americans_Spend_Sleeping,Day_Type %in% Day_Type2 & Sex %in% gender2)
      
      
      
      output$boxplot_analysis <- renderPlotly({
      
        p5 <- plot_ly(temp_data2, y = ~Avg_Sleeping_hours,boxpoints = "all", color = ~Age_Group, type = "box")
      
      })
      
      
      
      
      
    }
    
    
    
  })
  
  
}
