
##global:==============================================================================================================================
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#--------Script to install missing  Libraries------------------#

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

rm(list=ls())



# #Downloading and loading required packages
# 
req_packages <- c("shiny","shinythemes","dplyr","shinyalert","shinyBS","ggplot2", "shinyalert","shinyjs","lubridate","shinyWidgets",
                  "shinycssloaders","shinydashboardPlus","plotly","readxl","bsplus","tibble","shinydashboard"
)



library(readxl) # For Reading excel files

library(tibble) # for generating data summary

library(shiny) # for creating SHiny based App

library(shinyjs) # for enabling java scripting technology

library(shinydashboard) # for enabling Dashboard functionality

library(shinydashboardPlus) # Add-on elements to dashboard

library(plotly) # Generating interactive plots

library(shinyBS) # Bootstrap Techniques

library(lubridate) # dealing with dates

library(shinyWidgets) # custom widgets

library(shinycssloaders) # css functionality

library(ggplot2) # plotting functionality

library(shinythemes) # custom themes for shiny apps

library(shinyalert) # create alert

library(dplyr) # for data manipulation

setwd("G:/Data Science/Data Cated/w24")


Time_Americans_Spend_Sleeping <- read_excel("Time Americans Spend Sleeping.xlsx")



# -------------- Changing the column Names  ------------------------------------#

names(Time_Americans_Spend_Sleeping)[3] <- "Avg_Sleeping_hours"
names(Time_Americans_Spend_Sleeping)[4] <- "Standard_Error"
names(Time_Americans_Spend_Sleeping)[5] <- "Day_Type"
names(Time_Americans_Spend_Sleeping)[6] <- "Age_Group"


# --------------  Activity is common throughout :Sleeping, so is the Period : Annual   ------------------------------------#
glimpse(Time_Americans_Spend_Sleeping)

Time_Americans_Spend_Sleeping$Period <- NULL
Time_Americans_Spend_Sleeping$Activity <- NULL



#-------------- Inference: Sex both contains data which is average of male-female sleeping hours ----------#
both_data <- subset(Time_Americans_Spend_Sleeping,Sex=="Both")

actual_data <- subset(Time_Americans_Spend_Sleeping,Sex!="Both")


accumulate_by <- function(dat, var) {
  var <- lazyeval::f_eval(var, dat)
  lvls <- plotly:::getLevels(var)
  dats <- lapply(seq_along(lvls), function(x) {
    cbind(dat[var %in% lvls[seq(1, x)], ], frame = lvls[[x]])
  })
  dplyr::bind_rows(dats)
}

actual_data <<- as.data.frame(actual_data)
