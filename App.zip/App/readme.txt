****************** System Features      ***********************************************

Platform R 3.5.2 (RStudio)
Processor i7
Ram : 8G
ETA : 2hrs


**********************************************************************************************


****************** Code Pre-requisites   ***********************************************

1. Set working directory(Line 51) in global.R (code) and  save Excel workbook ("Time Americans Spend Sleeping.xlsx") in same folder

2. Open Global.R, Server.R and Ui.R  in RStudio (click on RunApp) [Choose Google chrome browser]


**********************************************************************************************

